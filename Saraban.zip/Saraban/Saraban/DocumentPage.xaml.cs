﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace Saraban
{
	public partial class DocumentPage : ContentPage
	{
		public DocumentPage()
		{
			InitializeComponent();

			var myImage = new Image()
			{
				Aspect = Aspect.AspectFill,
				Source = ImageSource.FromResource("Saraban.Resources.images.png")
			};
			//NavigationPage.SetTitleIcon(this, "image.png");
			SarabanClass sc = new SarabanClass();
			sc.BookNo = "125/85";
			sc.Topic = "แผนที่เมืองจังหวัดอุบลราชธานี";
			sc.CretaeDate = DateTime.Now.Date.ToString("dd/MM/yyyy");
			sc.Source = "images.png";//"/Users/patcharin/Projects/Saraban/Saraban/Resources/images.png";

			List<SarabanClass> lstSC = new List<SarabanClass>();
			for (int i = 0; i < 10; i++)
			{
				lstSC.Add(sc);
			}
			ListDocument.ItemsSource = lstSC;
		}
	}
}
