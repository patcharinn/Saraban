﻿using System;
namespace Saraban
{
	public class SarabanClass
	{
		public string BookNo { get; set; }
		public string Topic { get; set; }
		public string CretaeDate { get; set; }
		public string Source { get; set; }
	}
}
