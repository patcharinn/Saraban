﻿using Xamarin.Forms;
using System.Threading.Tasks;
namespace Saraban
{
	public partial class App : Application
	{
		public App()
		{
			InitializeComponent();
			Task.Delay(4000);
			//MainPage = new SarabanPage();
			//MainPage = new LoginPage();



			//MainPage.Title = "ระบบ";
			//MainPage.BackgroundImage = "https://developer.xamarin.com/recipes/ios/content_controls/navigation_controller/add_an_image_to_a_nav_bar_button/Images/UIBarButtonItemWithImage.png";
		}

		protected override  void OnStart()
		{
			// Handle when your app starts

		}

		protected override void OnSleep()
		{
			// Handle when your app sleeps
		}

		protected override void OnResume()
		{
			// Handle when your app resumes
		}
	}
}
