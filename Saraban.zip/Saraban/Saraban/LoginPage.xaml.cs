﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace Saraban
{
	public partial class LoginPage : ContentPage
	{
		public LoginPage()
		{
			InitializeComponent();
		}

		void Handle_Clicked(object sender, System.EventArgs e)
		{
		  	//NavigationPage.SetTitleIcon = "https://cdn4.iconfinder.com/data/icons/file-extensions-1/64/pdfs-48.png";
			Navigation.PushAsync(new DocumentPage() {Title = "Saraban System"});

			//string StrAlert = "\t\tกรุณาติดต่อสารบรรณกลาง" + "\n\t\tเพื่อเปิดใช้งาน" + "\n\n\n\t\t โทร 02-141-5988";
			////StrAlert = "\tไม่พบ Username \nกรุณาติดต่อ สารบรรณกลาง เพื่อเปิดใช้งาน" + "\n\n\n\t โทร 02-141-5988";
			//DisplayAlert("ไม่พบ Username", StrAlert, "OK");
		}
	}
}
