﻿using Xamarin.Forms;

namespace Saraban
{
	public partial class SarabanPage : ContentPage
	{
		public SarabanPage()
		{
			InitializeComponent();

		}
	}
}
